package com.pl.premier_zone.match;

import java.util.List;

public class FootballDataResponse {
    private List<FootballDataMatch> matches;

    public List<FootballDataMatch> getMatches() {
        return matches;
    }

    public void setMatches(List<FootballDataMatch> matches) {
        this.matches = matches;
    }
}

