package com.pl.premier_zone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PremierZoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
